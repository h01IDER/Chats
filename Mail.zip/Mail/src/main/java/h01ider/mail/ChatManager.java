package h01ider.mail;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Sound;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;

public class ChatManager {

    public void Whisp(Player sender, Player reciver, String msg){
        sender.sendMessage( ChatColor.LIGHT_PURPLE + "[ЛС] Вы -> " + ChatColor.AQUA + reciver.getName() + ": " + ChatColor.YELLOW + msg);
        sender.playSound(
                sender.getLocation(),
                Sound.BLOCK_HONEY_BLOCK_FALL,
                1.0F,
                1.0F
        );
        reciver.sendMessage(ChatColor.LIGHT_PURPLE + "[ЛС] " + ChatColor.AQUA + sender.getName() + ": " + ChatColor.YELLOW +  msg);
        reciver.playSound(
                sender.getLocation(),
                Sound.BLOCK_HONEY_BLOCK_FALL,
                1.0F,
                1.0F
        );
    }

    public void World(Player sender, String msg){
        Bukkit.broadcastMessage(ChatColor.GREEN + "[G] " + ChatColor.AQUA + sender.getName() + ": " + ChatColor.YELLOW +  msg);
    }

    public void Clan(Player sender, String msg){
        YamlConfiguration config = FileManager.getConfig();


    }

    public void Nabor(Player sender, String msg){
        Bukkit.broadcastMessage(ChatColor.GOLD + "[N] " + ChatColor.AQUA + sender.getName() + ": "  + ChatColor.YELLOW + msg);
    }

    public void Local(Player sender, String msg){
        getPlayerRadius(sender, 100.0)
                .forEach(nearby -> {
                    nearby.sendMessage(ChatColor.AQUA + sender.getName() + ": " + ChatColor.YELLOW +  msg);
                });
        sender.sendMessage(ChatColor.AQUA + sender.getName() + ": " + ChatColor.YELLOW +  msg);
    }

    public List<Player> getPlayerRadius(Player player, double rad){
        List<Player> nearby = new ArrayList<>();

        for (Entity entity : player.getWorld().getNearbyEntities(player.getLocation(), rad, rad, rad)){
            if (entity instanceof Player && !entity.equals(player)){
                nearby.add((Player) entity);
            }
        }
        return nearby;
    }
}

package h01ider.mail;

import jdk.nashorn.internal.runtime.regexp.joni.exception.SyntaxException;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Item;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.inventory.*;
import org.bukkit.event.player.*;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.BookMeta;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.*;

public final class Mail extends JavaPlugin implements Listener {
    private ChatManager chatManager;
    private MailManager mailManager;
    private Book book;
    private final Map<UUID, ItemStack[]> previousInv = new HashMap<>();
    private final Map<UUID, String> messageinf = new HashMap<>();
    private final Map<UUID, Boolean> isSend = new HashMap<>();
    private final Map<UUID, Location> mail = new HashMap<>();
    private final Map<UUID, Integer> Taskid = new HashMap<>();

    @Override
    public void onEnable() {
        FileManager.init(this);
        this.chatManager = new ChatManager();
        this.mailManager = new MailManager(this);
        this.book = new Book();

        getCommand("w").setExecutor(new Whisp());
        getCommand("m").setExecutor(new Whisp());
        getCommand("me").setExecutor(new Whisp());
        getServer().getPluginManager().registerEvents(this, this);
    }

    @Override
    public void onDisable() {
        // Plugin shutdown logic
    }


    @EventHandler
    public void onWhisp(WhispEvent event) {
        Player sender = event.getSender();
        Player reciver = event.getReciver();
        String message = event.getMessage();

        chatManager.Whisp(sender, reciver, message);
    }


    @EventHandler
    public void onWorld(AsyncPlayerChatEvent event){
        event.setCancelled(true);
        Player sender = event.getPlayer();
        String message = event.getMessage();
        Bukkit.getScheduler().runTask(this, () -> {

            Boolean isSending = isSend.get(sender.getUniqueId());

            if(isSending == null || !isSending){
                if (message.startsWith("!!")) {
                    String msg = message.substring(2);
                    chatManager.Nabor(sender, msg);
                } else if (message.startsWith("-")) {
                    String msg = message.substring(1);
                    chatManager.Clan(sender, msg);
                } else if (message.startsWith("!")) {
                    String msg = message.substring(1);
                    chatManager.World(sender, msg);
                } else {
                    chatManager.Local(sender, message); // Теперь это выполнится синхронно
                }
            } else if ((Bukkit.getOfflinePlayer(message).isOnline() || Bukkit.getOfflinePlayer(message).hasPlayedBefore()) && isSend.get(sender.getUniqueId()).equals(true)){
                mailManager.ReciverName(sender, Bukkit.getOfflinePlayer(message));
                mailManager.getBook(sender);
                book.setBook(sender);
                Integer taskid = new BukkitRunnable(){
                    @Override
                    public void run() {
                        checkPlayerDistance(sender);
                    }
                }.runTaskTimer(this, 0L, 100L).getTaskId();
                Taskid.put(sender.getUniqueId(), taskid);
            } else {
                mail.remove(sender.getUniqueId());
                sender.sendMessage(ChatColor.RED + "Такого игрока не существует");
                isSend.remove(sender.getUniqueId());
            }


        });
    }

    @EventHandler
    public void onPlace(BlockPlaceEvent event){
        Block block = event.getBlockAgainst();
        if (block.getType() == Material.BROWN_STAINED_GLASS){
            event.setCancelled(true);
        }
    }

    private void checkPlayerDistance(Player player){
        if (player.getWorld().equals(mail.get(player.getUniqueId()).getWorld())){
            double distance = player.getLocation().distance(mail.get(player.getUniqueId()));

            if (distance > 10) {
                PlayertooFar(player);
            }
        }
    }

    private void PlayertooFar(Player player){
        Inventory inventory = player.getInventory();
        for (int i = 0 ; i < inventory.getSize(); i++) {
            ItemStack item = inventory.getItem(i);

            if (book.isCorrectItem(player, item)) {
                inventory.setItem(i, mailManager.returnitem(player));
                player.sendMessage(ChatColor.RED + "Вы далеко отошли от почтовго ящика");
                mail.remove(player.getUniqueId());
                Bukkit.getScheduler().cancelTask(Taskid.get(player.getUniqueId()));
            }
        }
    }

    @EventHandler
    public void onMailbox(PlayerInteractEvent event) {
        if (event.getAction() == Action.RIGHT_CLICK_BLOCK) {
            Player player = event.getPlayer();
            Block block = event.getClickedBlock();

            if ((block.getType() == Material.BROWN_STAINED_GLASS || block.getType() == Material.BROWN_STAINED_GLASS_PANE) &&
                    player.getInventory().getItemInMainHand().getType() == Material.WRITTEN_BOOK) {

                mailManager.setItem(player);

            } else if ((block.getType() == Material.BROWN_STAINED_GLASS || block.getType() == Material.BROWN_STAINED_GLASS_PANE) &&
                    !(player.getInventory().getItemInMainHand().getType() == Material.WRITTEN_BOOK)) {

                mailManager.openMail(player);


                Location mailcord = new Location(Bukkit.getWorlds().get(0), block.getX(),block.getY(),block.getZ());
                mail.put(player.getUniqueId(), mailcord);
            }
        }
    }


    @EventHandler
    public void onInventory(InventoryClickEvent event) {
        Player player = (Player) event.getWhoClicked();
        ItemStack item = event.getCurrentItem();

        if (item == null) {
            return;
        }

        if (book.isCorrectItem(player, item)){
            getLogger().info("сработало условие на инвентарь");
            if (event.getInventory().getType() != InventoryType.PLAYER){
                event.setCancelled(true);
                player.closeInventory();
                player.sendMessage("§cВы не можете положить книгу в контейнер!");
            }
        }

        if (event.getView().getTitle().equals("§a§lВЛОЖЕНИЯ")) {

            if (item.getType() == Material.GREEN_WOOL && event.getRawSlot() == 8) {

                event.setCancelled(true);
                mailManager.colletItems(player, event.getClickedInventory());

            } else if (item.getType() == Material.WRITTEN_BOOK && event.getRawSlot() == 0) {
                event.setCancelled(true);
            }

            if (event.getRawSlot() < event.getClickedInventory().getSize() && event.getRawSlot() != 0) {

                event.setCancelled(false);

            }

        } else if (event.getView().getTitle().equals("§a§lДЕЙСТВИЕ")) {

            if (item.getType() == Material.PAPER && event.getRawSlot() == 3) {
                event.setCancelled(true);

                player.closeInventory();
                player.sendMessage( ChatColor.YELLOW + "Напиши имя игрока кому отправить письмо: ");
                isSend.put(player.getUniqueId(), true);

            } else if (item.getType() == Material.CHEST && event.getRawSlot() == 5) {

                event.setCancelled(true);

                mailManager.checkMailBox(player);

                mail.remove(player.getUniqueId());

            }

        } else if (event.getView().getTitle().equals("§a§lПОЛУЧКА")) {

            mail.remove(player.getUniqueId());

            if (item.getType() == Material.WRITABLE_BOOK) {
                event.setCancelled(true);

                String sender = item.getItemMeta().getDisplayName();
                YamlConfiguration config = FileManager.getConfig();
                UUID reciver = player.getUniqueId();

                ConfigurationSection message = config.getConfigurationSection(reciver + "." + Bukkit.getOfflinePlayer(sender).getUniqueId());
                messageinf.put(reciver, sender);

                Inventory messageinfo = Bukkit.createInventory(player, 9, sender);

                if (message.getString("message") != null) {
                    ItemStack book = new ItemStack(Material.WRITABLE_BOOK);

                    String lore = message.getString("message.head");

                    BookMeta meta = (BookMeta) book.getItemMeta();

                    meta.setDisplayName(sender);
                    meta.setLore(Collections.singletonList("Тема: " + lore));
                    meta.setAuthor(sender);
                    meta.addPage("От: " + sender + "\n\n"
                            + message.getString("message.text"));
                    book.setItemMeta(meta);
                    messageinfo.setItem(0, book);
                }

                ConfigurationSection itemssection = message.getConfigurationSection("items");
                int i = 1;
                if (itemssection != null) {
                    for (String itemkey : itemssection.getKeys(false)) {
                        ItemStack mailitem = itemssection.getItemStack(itemkey);
                        if (mailitem != null) {
                            messageinfo.setItem(i, mailitem);
                        }
                        i++;
                    }
                }
                player.closeInventory();
                player.openInventory(messageinfo);
            }
        }
    }


    @EventHandler
    public void OnInventoryOpen(InventoryOpenEvent event){
        if (event.getPlayer() instanceof Player){
            Player player = (Player) event.getPlayer();
            ItemStack[] mail = event.getInventory().getContents().clone();
            String sender = event.getView().getTitle();

            if (messageinf.containsKey(player.getUniqueId()) && messageinf.get(player.getUniqueId()).equals(sender)) {
                previousInv.put(player.getUniqueId(), mail);
            }
        }
    }

    @EventHandler
    public void onInventoryClose(InventoryCloseEvent event) {
        if (!(event.getPlayer() instanceof Player)) return;
        YamlConfiguration config = FileManager.getConfig();

        Player player = (Player) event.getPlayer();
        ItemStack cursor = player.getItemOnCursor();
        String sender = event.getView().getTitle();

        if (previousInv.containsKey(player.getUniqueId()) && messageinf.get(player.getUniqueId()).equals(sender)){

            if (event.getInventory().isEmpty()){
                config.set(player.getUniqueId() + "." + Bukkit.getPlayer(sender).getUniqueId(), null);
                config.set("mails." + Bukkit.getPlayer(sender).getUniqueId(), null);
                FileManager.saveconfig();
                return;
            }

            ItemStack[] after = event.getInventory().getContents().clone();


            ItemStack book = new ItemStack(Material.WRITABLE_BOOK);

            String lore = config.getString(player.getUniqueId() + "." + Bukkit.getOfflinePlayer(messageinf.get(player.getUniqueId())).getUniqueId() + ".message.head");

            BookMeta meta = (BookMeta) book.getItemMeta();

            meta.setDisplayName(sender);
            meta.setLore(Collections.singletonList("Тема: " + lore));
            meta.setAuthor(sender);
            meta.addPage("От: " + sender + "\n\n"
                    + config.getString(player.getUniqueId() + "." + Bukkit.getOfflinePlayer(messageinf.get(player.getUniqueId())).getUniqueId() + ".message.text"));
            book.setItemMeta(meta);

            boolean stat = false;

            for(int i = 0; i < after.length; i ++){
                if (after[i] != null && after[i].isSimilar(book)){
                    stat = true;
                    break;
                }
            }

            if (stat == false){
                config.set(player.getUniqueId() + "." + Bukkit.getOfflinePlayer( messageinf.get(player.getUniqueId())).getUniqueId() + ".message", null);
                messageinf.remove(player.getUniqueId());
            }

            ItemStack[] before = previousInv.get(player.getUniqueId());

            if(cursor != null && !cursor.getType().isAir()){
                for (int i = 0; i < after.length; i ++){
                    if(after[i] != null && after[i].isSimilar(cursor)){
                        after[i] = null;
                        break;
                    }
                }
            }

            if (!(Arrays.equals(after, before))) {
                ConfigurationSection section = config.getConfigurationSection(player.getUniqueId() + "." + Bukkit.getOfflinePlayer(sender).getUniqueId());
                section.set("items", null);
                List<ItemStack> items = Arrays.asList(after);
                ConfigurationSection itemsection = section.createSection("items");

                for (int i = 0; i < items.size(); i++) {
                    ItemStack item = items.get(i);
                    if (item != null && i != 0 && item.getType() != Material.AIR){
                        itemsection.set(String.valueOf(i), item);
                    }
                }
                FileManager.saveconfig();
            }
        }
    }


    @EventHandler
    public void onBook(PlayerEditBookEvent event) {

        Player player = event.getPlayer();

        BookMeta meta = event.getNewBookMeta();
        String page = meta.getPage(1);

        if (isSend.get(player.getUniqueId()) == Boolean.TRUE) {

            isSend.remove(player.getUniqueId());
            mailManager.Bookprocced(player, page, meta);

        }
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event){
        Player player = event.getPlayer();
        YamlConfiguration config = FileManager.getConfig();

        if (config.getString(player.getUniqueId().toString()) != null){
            player.sendMessage(ChatColor.YELLOW + "У вас непрочитаное письма");
        }
    }

    @EventHandler
    public void onPlayerDropItem(PlayerDropItemEvent event){
        getLogger().info("СРаботало условие на выброс книги");
        Item drop = event.getItemDrop();
        if (book.isCorrectItem(event.getPlayer(), event.getItemDrop().getItemStack())){
            event.setCancelled(true);
            event.getPlayer().sendMessage("§cВы не можете выбросить эту книгу!");
        }
    }

}
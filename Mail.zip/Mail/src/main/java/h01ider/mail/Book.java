package h01ider.mail;

import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.BookMeta;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.*;

public class Book {
    private final Map<UUID, String> bookUUID = new HashMap<>();

    public void setBook(Player player){
        ItemStack book = new ItemStack(Material.WRITABLE_BOOK);
        BookMeta meta = (BookMeta) book.getItemMeta();
        meta.setAuthor(player.getUniqueId().toString());
        meta.setDisplayName("Письмо");
        List<String> lore = new ArrayList<>();
        UUID uuid = UUID.randomUUID();
        lore.add(uuid.toString());
        meta.setLore(lore);
        book.setItemMeta(meta);
        bookUUID.put(player.getUniqueId(), uuid.toString());
        player.getInventory().setItemInMainHand(book);
        player.closeInventory();
    }

    public boolean isCorrectItem(Player player, ItemStack item) {
        if(item != null && item.hasItemMeta()) {
            ItemMeta meta = item.getItemMeta();
            if (meta.hasLore()) {
                for (String line : meta.getLore()) {
                    if (line.contains((bookUUID.get(player.getUniqueId())))) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

}

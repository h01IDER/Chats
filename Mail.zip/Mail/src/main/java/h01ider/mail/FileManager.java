package h01ider.mail;

import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;

public class FileManager {
    private static YamlConfiguration config;
    private static File configfile;

    public static void init(JavaPlugin plugin){
        configfile = new File(plugin.getDataFolder() + "/mail.yml");
        reloadconfig();
    }

    public static void reloadconfig(){
        config = YamlConfiguration.loadConfiguration(configfile);
    }

    public static YamlConfiguration getConfig(){
        return config;
    }

    public static void saveconfig(){
        try {
            config.save(configfile);
        } catch (IOException e) {
            System.out.println("ОШИБКА КУДА-ТО");
        }
    }
}
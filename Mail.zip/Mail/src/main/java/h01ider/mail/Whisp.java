package h01ider.mail;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;



import java.util.Arrays;

public class Whisp implements CommandExecutor {

    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args){
        if (!(sender instanceof Player)){
            return false;
        }

        Player player = (Player) sender;

        if (args.length < 2){
            player.sendMessage("Используй /w {имя игрока} {сообщение}");
            return false;
        }

        Player reciver = Bukkit.getPlayer(args[0]);
        if (reciver == null){
            player.sendMessage("Такого игрока нет в сети");
            return false;
        }

        String msg = String.join(" ", Arrays.copyOfRange(args, 1, args.length));

        WhispEvent event = new WhispEvent(player, msg, reciver);
        Bukkit.getPluginManager().callEvent(event);

        return true;
    }
}

package h01ider.mail;

import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;
import org.jetbrains.annotations.Contract;
import org.jetbrains.annotations.NotNull;

public class WhispEvent extends Event {
    private final Player player;
    private final String message;
    private final Player reciver;
    private static final HandlerList handlers = new HandlerList();

    public WhispEvent(Player player, String message, Player reciver) {
        this.player = player;
        this.message = message;
        this.reciver = reciver;
    }

    public Player getSender() {
        return player;
    }

    public Player getReciver() {
        return reciver;
    }

    public String getMessage() {
        return message;
    }

    @Contract(pure = true)
    public static HandlerList getHandlerList() {
        return handlers;
    }

    // 2. Метод экземпляра - для системы событий Bukkit
    @Override
    @NotNull
    public HandlerList getHandlers() {
        return handlers;
    }


}

package h01ider.mail;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Item;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.BookMeta;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.*;
import java.util.List;

public class MailManager {
    private final Map<UUID, ItemStack> oldhand = new HashMap<>();
    private final JavaPlugin plugin;
    private final Map<UUID, OfflinePlayer> recivername = new HashMap<>();

    public MailManager(JavaPlugin plugin) {
        this.plugin = plugin;
    }

    public void openMail(Player player){
        Inventory startChoose = Bukkit.createInventory(player, 9, "§a§lДЕЙСТВИЕ");

        ItemStack info = new ItemStack(Material.PAPER);
        ItemMeta infometa = info.getItemMeta();
        infometa.setDisplayName(ChatColor.GREEN + "Отправить письмо");
        info.setItemMeta(infometa);
        startChoose.setItem(3, info);

        info = new ItemStack(Material.CHEST);
        infometa = info.getItemMeta();
        infometa.setDisplayName(ChatColor.GREEN + "Получить письмо");
        info.setItemMeta(infometa);
        startChoose.setItem(5, info);

        player.openInventory(startChoose);
    }

    public void checkMailBox(Player player){
        YamlConfiguration config = FileManager.getConfig();

        String reciver = player.getUniqueId().toString();

        Inventory mail = Bukkit.createInventory(player, 18, "§a§lПОЛУЧКА");

        if (config.getString(reciver) != null) {

            ConfigurationSection mails = config.getConfigurationSection(reciver);

            int i = 0;
            for (String players : mails.getKeys(false)) {
                String name = Bukkit.getOfflinePlayer(UUID.fromString(players)).getName();
                String lore = mails.getString(players + ".message.head");

                ItemStack mp = new ItemStack(Material.WRITABLE_BOOK);
                ItemMeta info = mp.getItemMeta();
                info.setDisplayName(name);
                info.setLore(Collections.singletonList("Тема: " + lore));
                mp.setItemMeta(info);
                mail.setItem(i, mp);

                i += 1;
            }
        }
        player.closeInventory();
        player.openInventory(mail);
    }

    public void setItem(Player player){

        ItemStack item = player.getInventory().getItemInMainHand();

        if (item.getItemMeta() instanceof BookMeta) {

            BookMeta meta = (BookMeta) item.getItemMeta();

            YamlConfiguration config = FileManager.getConfig();

            if (meta.getAuthor() != null && meta.getAuthor().equals(player.getName())
                    && config.contains("mails." + player.getUniqueId())) {

                Inventory mailchest = Bukkit.createInventory(player, 9, "§a§lВЛОЖЕНИЯ");

                ItemStack info = new ItemStack(Material.WRITTEN_BOOK);
                ItemMeta infometa = info.getItemMeta();
                infometa.setDisplayName(config.getString(config.getString("mails." + player.getUniqueId()) + "." + player.getUniqueId() + ".message.head"));
                info.setItemMeta(infometa);
                mailchest.setItem(0, info);

                info = new ItemStack(Material.GREEN_WOOL);
                infometa = info.getItemMeta();
                infometa.setDisplayName(ChatColor.GREEN + "Подтвердить");
                infometa.setLore(Arrays.asList(
                        "Сложите предметы в этот инвертарь",
                        "Нажмите зеленую шерсть чтобы отправить"
                ));
                info.setItemMeta(infometa);

                mailchest.setItem(8, info);

                if (oldhand.containsKey(player.getUniqueId())) {
                    player.getInventory().setItemInMainHand(oldhand.get(player.getUniqueId()));
                    oldhand.remove(player.getUniqueId());
                }

                player.closeInventory();
                Bukkit.getScheduler().runTaskLater(plugin, ()->player.openInventory(mailchest), 3);


            } else {
                player.sendMessage(ChatColor.RED + "Ты не заполнил книгу");
            }
        }
    }

    public ItemStack returnitem(Player player){
        ItemStack item = oldhand.get(player.getUniqueId());
        oldhand.remove(player.getUniqueId());
        return item;
    }

    public void getBook(Player player){
        oldhand.put(player.getUniqueId(), player.getInventory().getItemInMainHand());
    }

    public void colletItems(Player player, Inventory inventory){
        List<ItemStack> collected = new ArrayList<>();

        for (int i = 1; i < inventory.getSize() - 1; i++) {
            ItemStack item = inventory.getItem(i);
            if (item != null && item.getType() != Material.AIR) {
                collected.add(item.clone());
            }
        }
        player.closeInventory();
        processItem(player, collected);
    }

    private void processItem(Player player, List<ItemStack> items) {
        YamlConfiguration config = FileManager.getConfig();
        if (items.isEmpty()) {
            player.sendMessage(ChatColor.GREEN + "Письмо отправлено!");
            if (recivername.get(player.getUniqueId()).isOnline()){
                Player reciver =  Bukkit.getPlayer(recivername.get(player.getUniqueId()).getName());
                reciver.sendMessage(ChatColor.YELLOW + "Вам пришло письмо");
            }
            recivername.remove(player.getUniqueId());
            return;
        }

        String reciveruuid = config.getString("mails." + player.getUniqueId());
        ConfigurationSection mail = config.getConfigurationSection(reciveruuid + "." + player.getUniqueId());
        ConfigurationSection itemsection = mail.createSection("items");

        for (int i = 0; i < items.size(); i++){
            ItemStack item = items.get(i);
            itemsection.set(String.valueOf(i), item);
        }

        FileManager.saveconfig();
        player.sendMessage(ChatColor.GREEN + "Письмо отправлено!");
        if (recivername.get(player.getUniqueId()).isOnline()){
            Player reciver =  Bukkit.getPlayer(recivername.get(player.getUniqueId()).getName());
            reciver.sendMessage(ChatColor.YELLOW + "Вам пришло письмо");
        }
        recivername.remove(player.getUniqueId());
    }

    public void Bookprocced(Player player, List<String> pages, BookMeta meta){
        YamlConfiguration config = FileManager.getConfig();


        OfflinePlayer offlinereciver = recivername.get(player.getUniqueId());
        String head = meta.getTitle();

        if(offlinereciver.hasPlayedBefore() || offlinereciver.isOnline()){
            config.set(offlinereciver.getUniqueId() + "." + player.getUniqueId() + ".message.head", head);
            config.set("mails." + player.getUniqueId(), offlinereciver.getUniqueId().toString());
            for (int i = 0; i < pages.size(); i++){
                config.set(offlinereciver.getUniqueId() + "." + player.getUniqueId() + ".message.text.page" + i, pages.get(i));
            }
            FileManager.saveconfig();
        }
    }

    public void ReciverName(Player sender, OfflinePlayer name){
        recivername.put(sender.getUniqueId(), name);
    }
}
